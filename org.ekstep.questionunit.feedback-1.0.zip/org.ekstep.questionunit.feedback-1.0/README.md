# org.ekstep.questionunit.mcq

Question Unit Plugin that enables creation of multiple choice questions.

### Usage

How do people use this plugin?

### Development

Please refer to [wiki](https://github.com/ekstep/Contributed-Plugins/wiki) for plugin development guidelines