org.ekstep.contentrenderer.questionUnitPlugin = Plugin.extend({
  _type: 'org.ekstep.questionUnitPlugin'
});